ATTENDANCE SPLASH LAUNCHER (separate app)

What it does:
- When the user opens this launcher app, it displays the supplied photo full-screen for 3 seconds.
- It then opens the installed SSUHS Attendance Tracker package:
  com.webapp.ssuhsattendancetrack.bkzz

Important limitations:
- This is a separate launcher app, not a modification of the attendance app.
- Opening the original attendance app icon directly will NOT show this picture. Users must open this new "Attendance Splash" app/shortcut instead.
- The attendance app must already be installed.
- This project does not alter attendance data, login, networking, or the original APK.

Build:
1. Open this folder in Android Studio (Giraffe or newer; AGP 8.7.3).
2. Let Gradle sync and install the Android SDK Platform 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated app-debug.apk.
5. Open "Attendance Splash" to test. Keep the original attendance app installed.
